# ctrl+desk - Plataforma de Gestão de Links

Sistema interno de gestão de chamados de telecom desenvolvido para a equipe de links da Mobit Soluções.

## 🚀 O que foi implementado

### ✅ Blocos 1-6 (Lovable)
- Login e autenticação simulada
- Layout base com sidebar e header
- **Triagem** - fila de chamados sem técnico atribuído
- **Minha Fila** - Kanban pessoal de cada analista
- **Filas da Equipe** - visão consolidada do gestor (redistribuição entre técnicos)
- **Modal de detalhes do chamado** - histórico, snooze, scripts, observações

### ✅ Blocos 7-11 (Claude)
- **Projetos de Entrega** - Kanban de projetos (entregas de link + cancelamentos)
- **Detalhes do Projeto** - visão individual com progresso e itens vinculados
- **Calendário** - agendamentos, prazos e snoozes
- **Dashboard** - KPIs e gráficos para o gestor
- **Clientes** - lista com métricas agregadas por cliente
- **Scripts** - biblioteca de respostas padrão
- **Configurações** - usuários, tipos de chamado e integração GLPI

### ✅ Extras
- Logo **ctrl+desk** integrado (sidebar e login)
- Paleta de cores azul marinho / branco / azul claro
- Dados mockados realistas (149 chamados, 28 clientes, 2 projetos)

---

## 📦 Instalação

### Pré-requisitos
- Node.js 18+ ou Bun
- npm ou bun

### Passos

1. **Clone o repositório** (se ainda não tiver)
```bash
git clone https://github.com/lzsanchez/ticket-triage-desk.git
cd ticket-triage-desk
```

2. **Instale as dependências**
```bash
npm install
# ou
bun install
```

3. **Rode o servidor de desenvolvimento**
```bash
npm run dev
# ou
bun run dev
```

4. **Abra no navegador**
```
http://localhost:5173
```

---

## 👥 Login

Na tela de login, clique em um dos 3 usuários mockados:

- **Luciano Sanchez** (Gestor) - acesso completo, incluindo Dashboard e Triagem
- **Pedro Melo** (Analista) - acesso à sua fila e recursos operacionais
- **Priscila Guanaz** (Analista) - acesso à sua fila e recursos operacionais

---

## 🗂️ Estrutura do Projeto

```
src/
├── components/
│   ├── Logo.tsx                    # Logo ctrl+desk
│   ├── auth/
│   │   └── LoginScreen.tsx
│   ├── layout/
│   │   ├── AppShell.tsx
│   │   ├── Header.tsx
│   │   └── Sidebar.tsx
│   ├── chamado/
│   │   ├── CardChamadoCompacto.tsx
│   │   └── ChamadoDetailsModal.tsx
│   ├── triagem/
│   │   ├── FiltrosMultiselect.tsx
│   │   └── VincularProjetoDialog.tsx
│   └── ui/                         # shadcn/ui components
├── data/
│   ├── mockChamados.ts             # 149 chamados mockados
│   ├── mockClientes.ts             # 28 clientes
│   ├── mockProjetos.ts             # 2 projetos de exemplo
│   ├── mockScripts.ts              # 4 scripts
│   └── mockUsuarios.ts             # 3 usuários
├── lib/
│   ├── auth.tsx                    # Context de autenticação
│   ├── store.tsx                   # Estado global (chamados, projetos)
│   ├── chamadoModal.tsx            # Context do modal de detalhes
│   ├── utils.ts                    # Funções utilitárias (aging, status visual)
│   └── users.ts                    # Usuários mockados
├── routes/
│   ├── __root.tsx
│   ├── index.tsx                   # Redirect para /minha-fila
│   ├── triagem.tsx
│   ├── minha-fila.tsx
│   ├── filas-equipe.tsx
│   ├── projetos.tsx                # ✅ NOVO
│   ├── projetos.$projetoId.tsx     # ✅ NOVO
│   ├── calendario.tsx              # ✅ NOVO
│   ├── dashboard.tsx               # ✅ NOVO
│   ├── clientes.tsx                # ✅ NOVO
│   ├── scripts.tsx                 # ✅ NOVO
│   └── configuracoes.tsx           # ✅ NOVO
├── types/
│   └── index.ts                    # Tipos TypeScript
└── styles.css
```

---

## 🔧 Próximos Passos (Roadmap)

### Fase 1 - Refinamentos (curto prazo)
- [ ] Implementar drag-and-drop no Kanban de projetos
- [ ] Adicionar criação de novos projetos (formulário)
- [ ] Implementar edição de scripts
- [ ] Fazer snooze funcional (notificação quando vencer)
- [ ] Melhorar responsividade mobile

### Fase 2 - Integração GLPI (médio prazo)
- [ ] Implementar autenticação real com API do GLPI
- [ ] Sincronização automática de chamados
- [ ] Webhook para atualização em tempo real
- [ ] Botão "Abrir no GLPI" funcional

### Fase 3 - Funcionalidades avançadas (longo prazo)
- [ ] Notificações por e-mail/Slack
- [ ] Exportação de relatórios (PDF/Excel)
- [ ] Auditoria completa de mudanças
- [ ] SLA tracking automático
- [ ] Integração com Teams/Slack

---

## 🎨 Design System

### Paleta de cores
- **Azul marinho** (`#0F2A4A`) - Primary, sidebar, elementos principais
- **Branco** (`#FFFFFF`) - Background, cards
- **Azul claro** (`#DBEAFE`) - Secondary, hover, seleções
- **Ciano** (`#06b6d4`) - Destaque do logo (+desk)
- **Âmbar** (`#D97706`) - Warning
- **Verde** (`#15803D`) - Success
- **Vermelho terra** (`#B91C1C`) - Destructive

### Tipografia
- **Inter** - corpo de texto
- **DM Sans ExtraBold** - logo ctrl+desk

---

## 📊 Dados Mockados

- **149 chamados** distribuídos entre 3 técnicos
- **28 clientes** (Rumolog, Sin Implante, Id Logistics, etc.)
- **2 projetos** de exemplo (Sin Implante - Expansão + Rumolog - Cancelamento Q2)
- **4 scripts** de respostas padrão
- Aging realista (0-331 dias)
- Status visual baseado em dias sem update

---

## 🐛 Problemas Conhecidos

- Drag-and-drop no Kanban de projetos ainda não implementado
- Criação/edição de projetos e scripts ainda não funcional
- Snooze não dispara notificações
- Configurações do GLPI são apenas placeholder (sem backend)

---

## 📝 Licença

Uso interno - Mobit Soluções. Não comercializado.

---

## 👨‍💻 Desenvolvedor

**Luciano Sanchez**  
Gestor da equipe de Links - Mobit Soluções

Construído com Claude (Anthropic) e Lovable.
