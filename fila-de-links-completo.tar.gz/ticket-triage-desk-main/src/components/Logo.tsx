import { cn } from "@/lib/utils";

type LogoSize = "sm" | "md" | "lg" | "xl";
type LogoTheme = "light" | "dark";

interface LogoProps {
  size?: LogoSize;
  theme?: LogoTheme;
  className?: string;
}

const sizeMap: Record<LogoSize, string> = {
  sm: "text-xl", // 20px - sidebar compacto
  md: "text-3xl", // 30px - sidebar normal
  lg: "text-5xl", // 48px - header
  xl: "text-8xl", // 96px - hero/login
};

export function Logo({ size = "md", theme = "light", className }: LogoProps) {
  const ctrlColor = theme === "dark" ? "text-white" : "text-[#1e3a8a]";
  const deskColor = "text-[#06b6d4]";

  return (
    <div
      className={cn(
        "inline-flex items-baseline font-['DM_Sans'] font-extrabold tracking-tight leading-none select-none",
        sizeMap[size],
        className,
      )}
      style={{ letterSpacing: "-0.02em" }}
    >
      <span className={ctrlColor}>ctrl</span>
      <span className={deskColor}>+desk</span>
    </div>
  );
}
