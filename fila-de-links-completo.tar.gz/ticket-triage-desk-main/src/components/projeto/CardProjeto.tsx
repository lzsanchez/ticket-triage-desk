import { Link } from "@tanstack/react-router";
import { mockClientes } from "@/data/mockClientes";
import { calcularAging } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar, AlertCircle, CheckCircle2, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import type { Projeto, Chamado } from "@/types";

type CardProjetoProps = {
  projeto: Projeto;
  chamados: Chamado[];
};

export function CardProjeto({ projeto, chamados }: CardProjetoProps) {
  const cliente = mockClientes.find((c) => c.id === projeto.clienteId);
  const chamadosDoProjeto = chamados.filter((c) => projeto.chamadosVinculados.includes(c.id));
  const chamadosConcluidos = chamadosDoProjeto.filter((c) => c.statusInterno === "concluido");
  const progresso = chamadosDoProjeto.length > 0 
    ? Math.round((chamadosConcluidos.length / chamadosDoProjeto.length) * 100)
    : 0;

  const aging = calcularAging(projeto.dataCriacao);
  
  // Status do prazo
  const getPrazoStatus = () => {
    if (!projeto.prazoPrometido) return null;
    const hoje = new Date();
    const prazo = new Date(projeto.prazoPrometido);
    const diasRestantes = Math.ceil((prazo.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diasRestantes < 0) return { cor: "text-destructive", icone: AlertCircle, texto: "Atrasado" };
    if (diasRestantes <= 3) return { cor: "text-warning", icone: AlertCircle, texto: `${diasRestantes}d restantes` };
    return { cor: "text-muted-foreground", icone: Calendar, texto: `${diasRestantes}d restantes` };
  };

  const prazoStatus = getPrazoStatus();

  // Tipos de chamado no projeto
  const tipos = new Set(chamadosDoProjeto.map(c => c.tipoChamado.categoria));

  return (
    <Link
      to="/projetos/$projetoId"
      params={{ projetoId: projeto.id }}
      className="block rounded-lg border border-border bg-card p-4 shadow-sm transition-all hover:shadow-md hover:border-primary/50"
    >
      <div className="space-y-3">
        {/* Header */}
        <div>
          <h3 className="font-semibold text-foreground leading-tight line-clamp-2">
            {projeto.nome}
          </h3>
          <p className="mt-1 text-xs text-muted-foreground font-medium">
            {cliente?.nome ?? "—"}
          </p>
        </div>

        {/* Progresso */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">
              {chamadosConcluidos.length} de {chamadosDoProjeto.length} itens
            </span>
            <span className="font-medium text-foreground">{progresso}%</span>
          </div>
          <Progress value={progresso} className="h-1.5" />
        </div>

        {/* Prazo */}
        {projeto.prazoPrometido && prazoStatus && (
          <div className={`flex items-center gap-1.5 text-xs ${prazoStatus.cor}`}>
            <prazoStatus.icone className="h-3.5 w-3.5" />
            <span className="font-medium">{prazoStatus.texto}</span>
          </div>
        )}

        {/* Tags dos tipos */}
        {tipos.size > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {Array.from(tipos).map((tipo) => (
              <Badge key={tipo} variant="secondary" className="text-[10px] font-medium px-2 py-0">
                {tipo}
              </Badge>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {aging}d
          </span>
          {progresso === 100 && (
            <span className="flex items-center gap-1 text-success">
              <CheckCircle2 className="h-3 w-3" />
              Concluído
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
