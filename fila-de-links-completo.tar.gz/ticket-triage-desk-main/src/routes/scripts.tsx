import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { mockScripts } from "@/data/mockScripts";
import type { Script } from "@/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Search, Plus, Copy, Check, FileText } from "lucide-react";

export const Route = createFileRoute("/scripts")({
  component: ScriptsPage,
});

function ScriptsPage() {
  return (
    <AppShell>
      <Scripts />
    </AppShell>
  );
}

function Scripts() {
  const [busca, setBusca] = useState("");
  const [scriptSelecionado, setScriptSelecionado] = useState<Script | null>(null);
  const [copiado, setCopiado] = useState(false);

  const scriptsFiltrados = useMemo(() => {
    if (!busca) return mockScripts;
    const termo = busca.toLowerCase();
    return mockScripts.filter(
      (s) =>
        s.nome.toLowerCase().includes(termo) ||
        s.tipoChamadoCategoria.toLowerCase().includes(termo) ||
        s.tags.some((t) => t.toLowerCase().includes(termo)),
    );
  }, [busca]);

  const scriptsPorCategoria = useMemo(() => {
    const map = new Map<string, Script[]>();
    scriptsFiltrados.forEach((script) => {
      const categoria = script.tipoChamadoCategoria;
      if (!map.has(categoria)) {
        map.set(categoria, []);
      }
      map.get(categoria)!.push(script);
    });
    return map;
  }, [scriptsFiltrados]);

  function copiarScript(script: Script) {
    navigator.clipboard.writeText(script.conteudo);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 2000);
  }

  return (
    <div>
      {/* Header */}
      <div className="flex items-end justify-between gap-4 pb-6">
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Respostas padrão</p>
          <div className="mt-1 flex items-baseline gap-3">
            <h1 className="text-3xl font-semibold tracking-tight text-foreground">Scripts</h1>
            <span className="text-2xl font-semibold text-muted-foreground">
              ({mockScripts.length})
            </span>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            Biblioteca de scripts para padronizar tratativas e respostas aos clientes.
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-1.5" />
          Novo Script
        </Button>
      </div>

      {/* Busca */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Buscar por nome, categoria ou tag..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Scripts agrupados por categoria */}
      <div className="space-y-6">
        {Array.from(scriptsPorCategoria.entries()).map(([categoria, scripts]) => (
          <div key={categoria}>
            <h2 className="text-lg font-semibold text-foreground mb-3">
              {categoria} ({scripts.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {scripts.map((script) => (
                <Card
                  key={script.id}
                  className="hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => setScriptSelecionado(script)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-sm line-clamp-1">{script.nome}</CardTitle>
                      </div>
                      <FileText className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                      {script.conteudo}
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {script.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-[10px] px-1.5 py-0">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>

      {scriptsFiltrados.length === 0 && (
        <div className="py-16 text-center">
          <p className="text-muted-foreground">Nenhum script encontrado com "{busca}"</p>
        </div>
      )}

      {/* Dialog de detalhes */}
      {scriptSelecionado && (
        <Dialog open={!!scriptSelecionado} onOpenChange={() => setScriptSelecionado(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{scriptSelecionado.nome}</DialogTitle>
              <DialogDescription>
                Categoria: {scriptSelecionado.tipoChamadoCategoria}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Conteúdo</label>
                <Textarea
                  value={scriptSelecionado.conteudo}
                  readOnly
                  rows={8}
                  className="font-mono text-xs"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Tags</label>
                <div className="flex flex-wrap gap-1.5">
                  {scriptSelecionado.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setScriptSelecionado(null)}>
                Fechar
              </Button>
              <Button onClick={() => copiarScript(scriptSelecionado)}>
                {copiado ? (
                  <>
                    <Check className="h-4 w-4 mr-1.5" />
                    Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-1.5" />
                    Copiar
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
