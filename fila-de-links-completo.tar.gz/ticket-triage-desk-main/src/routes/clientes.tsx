import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { useData } from "@/lib/store";
import { mockClientes } from "@/data/mockClientes";
import { calcularAging } from "@/lib/utils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Building2, TrendingUp } from "lucide-react";

export const Route = createFileRoute("/clientes")({
  component: ClientesPage,
});

function ClientesPage() {
  return (
    <AppShell>
      <Clientes />
    </AppShell>
  );
}

function Clientes() {
  const { chamados, projetos } = useData();
  const [busca, setBusca] = useState("");

  const clientesComDados = useMemo(() => {
    return mockClientes.map((cliente) => {
      const chamadosCliente = chamados.filter((c) => c.clienteId === cliente.id);
      const chamadosAtivos = chamadosCliente.filter((c) => c.statusInterno !== "concluido");
      const projetosCliente = projetos.filter((p) => p.clienteId === cliente.id);

      const agingMedio =
        chamadosAtivos.length > 0
          ? Math.round(
              chamadosAtivos.reduce((acc, c) => acc + calcularAging(c.dataAbertura), 0) /
                chamadosAtivos.length,
            )
          : 0;

      return {
        ...cliente,
        totalChamados: chamadosCliente.length,
        chamadosAtivos: chamadosAtivos.length,
        projetosAtivos: projetosCliente.length,
        agingMedio,
      };
    });
  }, [chamados, projetos]);

  const clientesFiltrados = useMemo(() => {
    if (!busca) return clientesComDados;
    const termo = busca.toLowerCase();
    return clientesComDados.filter(
      (c) =>
        c.nome.toLowerCase().includes(termo) ||
        c.entidadeGLPI.toLowerCase().includes(termo),
    );
  }, [clientesComDados, busca]);

  const clientesOrdenados = useMemo(
    () => clientesFiltrados.sort((a, b) => b.chamadosAtivos - a.chamadosAtivos),
    [clientesFiltrados],
  );

  return (
    <div>
      {/* Header */}
      <div className="flex items-end justify-between gap-4 pb-6">
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Base de clientes</p>
          <div className="mt-1 flex items-baseline gap-3">
            <h1 className="text-3xl font-semibold tracking-tight text-foreground">Clientes</h1>
            <span className="text-2xl font-semibold text-muted-foreground">
              ({mockClientes.length})
            </span>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            Visão consolidada de chamados, projetos e aging por cliente.
          </p>
        </div>
      </div>

      {/* Busca */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Buscar por nome ou entidade..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Grid de clientes */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {clientesOrdenados.map((cliente) => (
          <Card key={cliente.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <CardTitle className="text-base line-clamp-1">{cliente.nome}</CardTitle>
                  <CardDescription className="text-xs line-clamp-1 mt-1">
                    {cliente.entidadeGLPI}
                  </CardDescription>
                </div>
                <Building2 className="h-5 w-5 text-muted-foreground flex-shrink-0" />
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-muted-foreground">Chamados ativos</p>
                  <p className="text-2xl font-bold text-foreground">{cliente.chamadosAtivos}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Projetos</p>
                  <p className="text-2xl font-bold text-foreground">{cliente.projetosAtivos}</p>
                </div>
              </div>

              {cliente.chamadosAtivos > 0 && (
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">
                    Aging médio: <span className="font-semibold text-foreground">{cliente.agingMedio}d</span>
                  </span>
                </div>
              )}

              {cliente.chamadosAtivos === 0 && (
                <Badge variant="secondary" className="text-xs">
                  Sem chamados ativos
                </Badge>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {clientesFiltrados.length === 0 && (
        <div className="py-16 text-center">
          <p className="text-muted-foreground">Nenhum cliente encontrado com "{busca}"</p>
        </div>
      )}
    </div>
  );
}
