import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { useData } from "@/lib/store";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Package, Ban, Inbox } from "lucide-react";
import { CardProjeto } from "@/components/projeto/CardProjeto";
import type { Projeto } from "@/types";

export const Route = createFileRoute("/projetos")({
  component: ProjetosPage,
});

const COLUNAS_ENTREGA = [
  { id: "Solicitado", label: "Solicitado" },
  { id: "Precificação", label: "Precificação" },
  { id: "Validação Comercial", label: "Validação Comercial" },
  { id: "Aguardando Viabilidade", label: "Aguardando Viabilidade" },
  { id: "Agendado", label: "Agendado" },
  { id: "Instalado", label: "Instalado" },
  { id: "Entregue", label: "Entregue" },
];

const COLUNAS_CANCELAMENTO = [
  { id: "Solicitado", label: "Solicitado" },
  { id: "Consulta de Multa", label: "Consulta de Multa" },
  { id: "Análise Interna", label: "Análise Interna" },
  { id: "Autorização Cliente", label: "Autorização Cliente" },
  { id: "Em Execução", label: "Em Execução" },
  { id: "Concluído", label: "Concluído" },
];

function ProjetosPage() {
  return (
    <AppShell>
      <Projetos />
    </AppShell>
  );
}

function Projetos() {
  const { projetos, chamados } = useData();
  const [tabAtiva, setTabAtiva] = useState<"entrega" | "cancelamento">("entrega");

  const projetosEntrega = useMemo(
    () => projetos.filter((p) => p.tipo === "entrega_link"),
    [projetos],
  );

  const projetosCancelamento = useMemo(
    () => projetos.filter((p) => p.tipo === "cancelamento"),
    [projetos],
  );

  return (
    <div className="mx-auto max-w-7xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Gestão de Projetos</p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight text-foreground">Projetos</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Acompanhe entregas e cancelamentos agrupados por projeto.
          </p>
        </div>
        <Button size="sm">
          <Plus className="mr-1.5 h-4 w-4" />
          Novo Projeto
        </Button>
      </div>

      <Tabs value={tabAtiva} onValueChange={(v) => setTabAtiva(v as any)} className="mt-6">
        <TabsList>
          <TabsTrigger value="entrega" className="gap-2">
            <Package className="h-4 w-4" />
            Entregas de Link
            <span className="ml-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
              {projetosEntrega.length}
            </span>
          </TabsTrigger>
          <TabsTrigger value="cancelamento" className="gap-2">
            <Ban className="h-4 w-4" />
            Cancelamentos
            <span className="ml-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
              {projetosCancelamento.length}
            </span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="entrega" className="mt-4">
          <KanbanProjetos projetos={projetosEntrega} colunas={COLUNAS_ENTREGA} chamados={chamados} />
        </TabsContent>

        <TabsContent value="cancelamento" className="mt-4">
          <KanbanProjetos
            projetos={projetosCancelamento}
            colunas={COLUNAS_CANCELAMENTO}
            chamados={chamados}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

type KanbanProjetosProps = {
  projetos: Projeto[];
  colunas: typeof COLUNAS_ENTREGA;
  chamados: any[];
};

function KanbanProjetos({ projetos, colunas, chamados }: KanbanProjetosProps) {
  const projetosPorColuna = useMemo(() => {
    const map = new Map<string, Projeto[]>();
    colunas.forEach((col) => map.set(col.id, []));
    projetos.forEach((p) => {
      const lista = map.get(p.etapaAtual);
      if (lista) lista.push(p);
    });
    return map;
  }, [projetos, colunas]);

  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {colunas.map((coluna) => {
        const projetosColuna = projetosPorColuna.get(coluna.id) || [];
        return (
          <div key={coluna.id} className="flex-shrink-0" style={{ width: "300px" }}>
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-semibold text-foreground">{coluna.label}</span>
              <Badge variant="secondary" className="text-xs">
                {projetosColuna.length}
              </Badge>
            </div>

            <div className="space-y-3">
              {projetosColuna.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-md border border-dashed border-border bg-muted/30 px-4 py-12 text-center">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted mb-2">
                    <Inbox className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <p className="text-xs text-muted-foreground">Nenhum projeto</p>
                </div>
              ) : (
                projetosColuna.map((projeto) => (
                  <CardProjeto key={projeto.id} projeto={projeto} chamados={chamados} />
                ))
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
