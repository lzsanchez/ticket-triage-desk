import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { useData } from "@/lib/store";
import { mockClientes } from "@/data/mockClientes";
import { mockUsuarios } from "@/data/mockUsuarios";
import { calcularAging, calcularDiasSemUpdate, getStatusVisual } from "@/lib/utils";
import { useChamadoModal } from "@/lib/chamadoModal";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { ChevronLeft, Calendar, FileText, Plus, ExternalLink } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export const Route = createFileRoute("/projetos/$projetoId")({
  component: ProjetoDetalhesPage,
});

function ProjetoDetalhesPage() {
  return (
    <AppShell>
      <ProjetoDetalhes />
    </AppShell>
  );
}

function ProjetoDetalhes() {
  const { projetoId } = Route.useParams();
  const { projetos, chamados } = useData();
  const { abrir } = useChamadoModal();
  const [observacoes, setObservacoes] = useState("");

  const projeto = useMemo(
    () => projetos.find((p) => p.id === projetoId),
    [projetos, projetoId],
  );

  const cliente = useMemo(
    () => (projeto ? mockClientes.find((c) => c.id === projeto.clienteId) : null),
    [projeto],
  );

  const chamadosVinculados = useMemo(
    () =>
      projeto
        ? chamados.filter((c) => projeto.chamadosVinculados.includes(c.id))
        : [],
    [chamados, projeto],
  );

  if (!projeto) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <p className="text-lg font-semibold text-foreground">Projeto não encontrado</p>
        <Link to="/projetos" className="mt-4 text-sm text-primary hover:underline">
          Voltar para Projetos
        </Link>
      </div>
    );
  }

  const totalItens = projeto.chamadosVinculados.length;
  const itensConcluidos = chamadosVinculados.filter(
    (c) => c.statusInterno === "concluido",
  ).length;
  const progresso = totalItens > 0 ? (itensConcluidos / totalItens) * 100 : 0;

  // Status do prazo
  const hoje = new Date();
  const prazo = projeto.prazoPrometido;
  let statusPrazo: "ok" | "atencao" | "atrasado" | null = null;
  let textoStatus = "";

  if (prazo) {
    const diff = prazo.getTime() - hoje.getTime();
    const diasRestantes = Math.ceil(diff / (1000 * 60 * 60 * 24));

    if (diasRestantes < 0) {
      statusPrazo = "atrasado";
      textoStatus = `Atrasado ${Math.abs(diasRestantes)} ${Math.abs(diasRestantes) === 1 ? "dia" : "dias"}`;
    } else if (diasRestantes <= 3) {
      statusPrazo = "atencao";
      textoStatus =
        diasRestantes === 0
          ? "Vence hoje"
          : diasRestantes === 1
            ? "Vence amanhã"
            : `${diasRestantes} dias restantes`;
    } else {
      statusPrazo = "ok";
      textoStatus = `${diasRestantes} dias restantes`;
    }
  }

  return (
    <div className="mx-auto max-w-5xl">
      {/* Breadcrumb */}
      <Link
        to="/projetos"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4"
      >
        <ChevronLeft className="h-4 w-4" />
        Voltar para Projetos
      </Link>

      {/* Header */}
      <div className="mb-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <Badge variant="secondary" className="mb-2">
              {projeto.tipo === "entrega_link" ? "Entrega de Link" : "Cancelamento"}
            </Badge>
            <h1 className="text-3xl font-semibold tracking-tight text-foreground">
              {projeto.nome}
            </h1>
            <p className="mt-1 text-lg text-muted-foreground">{cliente?.nome}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Plus className="h-4 w-4 mr-1.5" />
              Adicionar chamado
            </Button>
            <Button variant="outline">Editar projeto</Button>
          </div>
        </div>

        {/* Badges de status */}
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <Badge variant="outline" className="text-sm px-3 py-1">
            Etapa: {projeto.etapaAtual}
          </Badge>
          {prazo && (
            <Badge
              variant="outline"
              className={`text-sm px-3 py-1 ${
                statusPrazo === "atrasado"
                  ? "border-red-600 text-red-600"
                  : statusPrazo === "atencao"
                    ? "border-amber-600 text-amber-600"
                    : "border-green-600 text-green-600"
              }`}
            >
              <Calendar className="h-3.5 w-3.5 mr-1.5" />
              {textoStatus}
            </Badge>
          )}
        </div>

        {/* Progresso */}
        <div className="mt-4 p-4 rounded-lg border border-border bg-card">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-foreground">Progresso geral</span>
            <span className="text-sm font-semibold text-foreground">
              {itensConcluidos} de {totalItens} itens ({Math.round(progresso)}%)
            </span>
          </div>
          <Progress value={progresso} className="h-2" />
        </div>
      </div>

      <Separator className="my-6" />

      {/* Seção: Itens do projeto */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold text-foreground mb-4">
          Itens do projeto ({totalItens})
        </h2>
        <div className="space-y-2">
          {chamadosVinculados.length === 0 ? (
            <div className="rounded-md border border-dashed border-border bg-muted/20 p-8 text-center">
              <FileText className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                Nenhum chamado vinculado a este projeto ainda.
              </p>
            </div>
          ) : (
            chamadosVinculados.map((chamado) => (
              <ItemChamado key={chamado.id} chamadoId={chamado.id} />
            ))
          )}
        </div>
      </section>

      <Separator className="my-6" />

      {/* Seção: Linha do tempo do projeto */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold text-foreground mb-4">Linha do tempo</h2>
        <div className="rounded-lg border border-border bg-card p-6">
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>
              Criado em {format(projeto.dataCriacao, "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
            </span>
          </div>
          {prazo && (
            <div className="flex items-center gap-3 text-sm text-muted-foreground mt-2">
              <Calendar className="h-4 w-4" />
              <span>
                Prazo prometido: {format(prazo, "dd/MM/yyyy", { locale: ptBR })}
              </span>
            </div>
          )}
          <p className="mt-4 text-xs text-muted-foreground">
            Timeline detalhada com transições entre etapas será implementada em breve.
          </p>
        </div>
      </section>

      <Separator className="my-6" />

      {/* Seção: Observações */}
      <section>
        <h2 className="text-xl font-semibold text-foreground mb-4">Observações do projeto</h2>
        <div className="rounded-lg border border-border bg-card p-4">
          {projeto.observacoes ? (
            <div className="mb-4">
              <p className="text-sm text-foreground whitespace-pre-wrap">{projeto.observacoes}</p>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground mb-4">Nenhuma observação registrada.</p>
          )}
          <Textarea
            placeholder="Adicionar nova observação..."
            value={observacoes}
            onChange={(e) => setObservacoes(e.target.value)}
            rows={3}
            className="mb-2"
          />
          <Button size="sm" disabled={!observacoes.trim()}>
            Salvar observação
          </Button>
        </div>
      </section>
    </div>
  );
}

function ItemChamado({ chamadoId }: { chamadoId: string }) {
  const { chamados } = useData();
  const { abrir } = useChamadoModal();

  const chamado = useMemo(
    () => chamados.find((c) => c.id === chamadoId),
    [chamados, chamadoId],
  );

  if (!chamado) return null;

  const cliente = mockClientes.find((c) => c.id === chamado.clienteId);
  const tecnico = mockUsuarios.find((u) => u.id === chamado.tecnicoId);
  const aging = calcularAging(chamado.dataAbertura);
  const statusVisual = getStatusVisual(chamado);

  const corStatus = {
    verde: "bg-green-500",
    amarelo: "bg-amber-500",
    vermelho: "bg-red-500",
    cinza: "bg-gray-400",
  }[statusVisual];

  return (
    <button
      type="button"
      onClick={() => abrir(chamado.id)}
      className="w-full rounded-md border border-border bg-card p-3 text-left transition-all hover:shadow-sm hover:border-primary/50"
    >
      <div className="flex items-start gap-3">
        {/* Bolinha de status */}
        <div className={`mt-1.5 h-2.5 w-2.5 rounded-full ${corStatus} flex-shrink-0`} />

        {/* Conteúdo */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-semibold text-primary">
                  {chamado.id}
                </span>
                <Badge
                  variant={chamado.statusInterno === "concluido" ? "default" : "secondary"}
                  className="text-[10px] px-1.5 py-0"
                >
                  {chamado.statusInterno.replace(/_/g, " ")}
                </Badge>
              </div>
              <p className="mt-0.5 text-sm font-medium text-foreground line-clamp-1">
                {chamado.titulo}
              </p>
            </div>
            <ExternalLink className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
          </div>

          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
            {tecnico && <span>Técnico: {tecnico.nome.split(" ")[0]}</span>}
            <span>·</span>
            <span>{aging === 0 ? "Hoje" : `${aging}d de aging`}</span>
            <span>·</span>
            <span className="capitalize">{chamado.prioridade}</span>
          </div>
        </div>
      </div>
    </button>
  );
}
