import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { useData } from "@/lib/store";
import { mockClientes } from "@/data/mockClientes";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from "lucide-react";
import {
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  format,
  isSameDay,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
  isSameMonth,
  isToday,
} from "date-fns";
import { ptBR } from "date-fns/locale";

export const Route = createFileRoute("/calendario")({
  component: CalendarioPage,
});

type EventoCalendario = {
  id: string;
  tipo: "instalacao" | "prazo_projeto" | "snooze_vencido";
  titulo: string;
  data: Date;
  clienteNome?: string;
  cor: string;
};

function CalendarioPage() {
  return (
    <AppShell>
      <Calendario />
    </AppShell>
  );
}

function Calendario() {
  const { projetos, chamados } = useData();
  const [mesAtual, setMesAtual] = useState(new Date());

  // Gerar eventos
  const eventos = useMemo(() => {
    const eventosArray: EventoCalendario[] = [];

    // Eventos de prazo de projeto
    projetos.forEach((projeto) => {
      if (projeto.prazoPrometido) {
        const cliente = mockClientes.find((c) => c.id === projeto.clienteId);
        eventosArray.push({
          id: `projeto-${projeto.id}`,
          tipo: "prazo_projeto",
          titulo: projeto.nome,
          data: projeto.prazoPrometido,
          clienteNome: cliente?.nome,
          cor: "#06b6d4", // ciano
        });
      }
    });

    // Eventos de snooze vencido (futuros)
    chamados.forEach((chamado) => {
      if (chamado.snoozeAte && chamado.snoozeAte > new Date()) {
        const cliente = mockClientes.find((c) => c.id === chamado.clienteId);
        eventosArray.push({
          id: `snooze-${chamado.id}`,
          tipo: "snooze_vencido",
          titulo: `Snooze: ${chamado.titulo}`,
          data: chamado.snoozeAte,
          clienteNome: cliente?.nome,
          cor: "#f59e0b", // âmbar
        });
      }
    });

    // TODO: Adicionar eventos de "instalação agendada" quando tivermos esse campo nos chamados

    return eventosArray;
  }, [projetos, chamados]);

  // Filtrar eventos do mês atual
  const eventosMes = useMemo(() => {
    const inicio = startOfMonth(mesAtual);
    const fim = endOfMonth(mesAtual);
    return eventos.filter((e) => e.data >= inicio && e.data <= fim);
  }, [eventos, mesAtual]);

  // Gerar dias do calendário (incluindo dias da semana anterior/posterior)
  const diasCalendario = useMemo(() => {
    const inicio = startOfWeek(startOfMonth(mesAtual), { weekStartsOn: 0 });
    const fim = endOfWeek(endOfMonth(mesAtual), { weekStartsOn: 0 });
    return eachDayOfInterval({ start: inicio, end: fim });
  }, [mesAtual]);

  function proximoMes() {
    setMesAtual((prev) => addMonths(prev, 1));
  }

  function mesAnterior() {
    setMesAtual((prev) => subMonths(prev, 1));
  }

  function voltarHoje() {
    setMesAtual(new Date());
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-end justify-between gap-4 pb-6">
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Visão temporal</p>
          <div className="mt-1 flex items-baseline gap-3">
            <h1 className="text-3xl font-semibold tracking-tight text-foreground">Calendário</h1>
            <span className="text-2xl font-semibold text-muted-foreground">
              ({eventosMes.length} {eventosMes.length === 1 ? "evento" : "eventos"})
            </span>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            Agendamentos de instalação, prazos prometidos e snoozes vencidos.
          </p>
        </div>
      </div>

      {/* Controles do calendário */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <h2 className="text-xl font-semibold text-foreground capitalize">
            {format(mesAtual, "MMMM 'de' yyyy", { locale: ptBR })}
          </h2>
          <div className="flex gap-1">
            <Button variant="outline" size="sm" onClick={mesAnterior}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={proximoMes}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={voltarHoje}>
          <CalendarIcon className="h-4 w-4 mr-1.5" />
          Hoje
        </Button>
      </div>

      {/* Legenda */}
      <div className="flex items-center gap-4 mb-4 text-xs">
        <div className="flex items-center gap-1.5">
          <div className="h-3 w-3 rounded-full bg-[#06b6d4]" />
          <span className="text-muted-foreground">Prazo de projeto</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="h-3 w-3 rounded-full bg-[#f59e0b]" />
          <span className="text-muted-foreground">Snooze vencido</span>
        </div>
      </div>

      {/* Grid do calendário */}
      <div className="flex-1 rounded-lg border border-border bg-card overflow-hidden">
        {/* Header dos dias da semana */}
        <div className="grid grid-cols-7 border-b border-border bg-muted/30">
          {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((dia) => (
            <div
              key={dia}
              className="p-2 text-center text-xs font-semibold text-muted-foreground"
            >
              {dia}
            </div>
          ))}
        </div>

        {/* Grid de dias */}
        <div className="grid grid-cols-7 auto-rows-fr" style={{ gridAutoRows: "1fr" }}>
          {diasCalendario.map((dia, idx) => {
            const eventosNoDia = eventos.filter((e) => isSameDay(e.data, dia));
            const noMesAtual = isSameMonth(dia, mesAtual);
            const ehHoje = isToday(dia);

            return (
              <div
                key={idx}
                className={`min-h-[100px] border-r border-b border-border p-2 ${
                  !noMesAtual ? "bg-muted/10" : "bg-card"
                } ${ehHoje ? "bg-primary/5" : ""}`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span
                    className={`text-sm font-semibold ${
                      ehHoje
                        ? "flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground"
                        : noMesAtual
                          ? "text-foreground"
                          : "text-muted-foreground"
                    }`}
                  >
                    {format(dia, "d")}
                  </span>
                </div>

                <div className="space-y-1">
                  {eventosNoDia.map((evento) => (
                    <div
                      key={evento.id}
                      className="rounded px-1.5 py-0.5 text-[10px] font-medium truncate"
                      style={{
                        backgroundColor: evento.cor,
                        color: "#ffffff",
                      }}
                      title={`${evento.titulo}${evento.clienteNome ? ` - ${evento.clienteNome}` : ""}`}
                    >
                      {evento.titulo}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
