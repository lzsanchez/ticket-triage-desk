import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { useAuth } from "@/lib/auth";
import { useData } from "@/lib/store";
import { mockClientes } from "@/data/mockClientes";
import { mockUsuarios } from "@/data/mockUsuarios";
import { calcularAging, calcularDiasSemUpdate } from "@/lib/utils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { AlertCircle, TrendingUp, Clock, FolderOpen } from "lucide-react";

export const Route = createFileRoute("/dashboard")({
  component: DashboardPage,
});

function DashboardPage() {
  return (
    <AppShell>
      <Dashboard />
    </AppShell>
  );
}

function Dashboard() {
  const { user } = useAuth();
  const { chamados, projetos } = useData();
  const [incluirProjetosLongos, setIncluirProjetosLongos] = useState(true);

  if (!user) return null;
  if (user.role !== "gestor") return <Navigate to="/" />;

  // Filtrar chamados (excluir projetos longos se toggle desativado)
  const chamadosFiltrados = useMemo(() => {
    if (incluirProjetosLongos) return chamados;

    const projetosLongosIds = new Set(
      projetos
        .filter((p) => {
          const agingProjeto = calcularAging(p.dataCriacao);
          return agingProjeto > 90;
        })
        .flatMap((p) => p.chamadosVinculados),
    );

    return chamados.filter((c) => !projetosLongosIds.has(c.id));
  }, [chamados, projetos, incluirProjetosLongos]);

  // KPIs
  const totalBacklog = chamadosFiltrados.filter((c) => c.statusInterno !== "concluido").length;
  const chamadosParados = chamadosFiltrados.filter(
    (c) => calcularDiasSemUpdate(c.dataUltimaAtualizacao) > 7 && c.statusInterno !== "concluido",
  ).length;
  const agingMedio = useMemo(() => {
    const chamadosAtivos = chamadosFiltrados.filter((c) => c.statusInterno !== "concluido");
    if (chamadosAtivos.length === 0) return 0;
    const soma = chamadosAtivos.reduce((acc, c) => acc + calcularAging(c.dataAbertura), 0);
    return Math.round(soma / chamadosAtivos.length);
  }, [chamadosFiltrados]);

  const snoozesVencidos = chamadosFiltrados.filter(
    (c) => c.snoozeAte && c.snoozeAte < new Date(),
  ).length;

  const projetosEmRisco = useMemo(() => {
    const hoje = new Date();
    return projetos.filter((p) => {
      if (!p.prazoPrometido) return false;
      const diff = p.prazoPrometido.getTime() - hoje.getTime();
      const diasRestantes = Math.ceil(diff / (1000 * 60 * 60 * 24));
      return diasRestantes < 0 || diasRestantes <= 3;
    }).length;
  }, [projetos]);

  // Dados para gráficos

  // 1. Distribuição por técnico
  const dadosPorTecnico = useMemo(() => {
    const map = new Map<string, number>();
    chamadosFiltrados
      .filter((c) => c.statusInterno !== "concluido")
      .forEach((c) => {
        if (c.tecnicoId) {
          map.set(c.tecnicoId, (map.get(c.tecnicoId) || 0) + 1);
        }
      });

    return Array.from(map.entries()).map(([id, count]) => {
      const usuario = mockUsuarios.find((u) => u.id === id);
      return {
        nome: usuario?.nome.split(" ")[0] || id,
        chamados: count,
      };
    });
  }, [chamadosFiltrados]);

  // 2. Distribuição por tipo
  const dadosPorTipo = useMemo(() => {
    const map = new Map<string, number>();
    chamadosFiltrados
      .filter((c) => c.statusInterno !== "concluido")
      .forEach((c) => {
        const tipo = c.tipoChamado.categoria;
        map.set(tipo, (map.get(tipo) || 0) + 1);
      });

    return Array.from(map.entries()).map(([tipo, count]) => ({
      tipo,
      valor: count,
    }));
  }, [chamadosFiltrados]);

  // 3. Aging por faixas
  const dadosAgingFaixas = useMemo(() => {
    const faixas = [
      { label: "0-7d", min: 0, max: 7, count: 0 },
      { label: "8-15d", min: 8, max: 15, count: 0 },
      { label: "16-30d", min: 16, max: 30, count: 0 },
      { label: "31-60d", min: 31, max: 60, count: 0 },
      { label: "61-90d", min: 61, max: 90, count: 0 },
      { label: "90+d", min: 91, max: 99999, count: 0 },
    ];

    chamadosFiltrados
      .filter((c) => c.statusInterno !== "concluido")
      .forEach((c) => {
        const aging = calcularAging(c.dataAbertura);
        const faixa = faixas.find((f) => aging >= f.min && aging <= f.max);
        if (faixa) faixa.count++;
      });

    return faixas.map((f) => ({ faixa: f.label, chamados: f.count }));
  }, [chamadosFiltrados]);

  // 4. Top 5 clientes
  const top5Clientes = useMemo(() => {
    const map = new Map<string, number>();
    chamadosFiltrados
      .filter((c) => c.statusInterno !== "concluido")
      .forEach((c) => {
        map.set(c.clienteId, (map.get(c.clienteId) || 0) + 1);
      });

    return Array.from(map.entries())
      .map(([id, count]) => {
        const cliente = mockClientes.find((c) => c.id === id);
        return {
          nome: cliente?.nome || id,
          chamados: count,
        };
      })
      .sort((a, b) => b.chamados - a.chamados)
      .slice(0, 5);
  }, [chamadosFiltrados]);

  const CORES = ["#1e3a8a", "#06b6d4", "#3b82f6", "#0ea5e9", "#64748b"];

  return (
    <div>
      {/* Header */}
      <div className="flex items-end justify-between gap-4 pb-6">
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Visão executiva</p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight text-foreground">Dashboard</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Métricas consolidadas da operação de links.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Switch
            id="projetos-longos"
            checked={incluirProjetosLongos}
            onCheckedChange={setIncluirProjetosLongos}
          />
          <Label htmlFor="projetos-longos" className="text-sm cursor-pointer">
            Incluir projetos longos (90+ dias)
          </Label>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <FolderOpen className="h-3.5 w-3.5" />
              Total no backlog
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">{totalBacklog}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <AlertCircle className="h-3.5 w-3.5" />
              Chamados parados
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">{chamadosParados}</div>
            <p className="text-xs text-muted-foreground mt-1">&gt;7 dias sem update</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" />
              Aging médio
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">{agingMedio}d</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <TrendingUp className="h-3.5 w-3.5" />
              Snoozes vencidos
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-600">{snoozesVencidos}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <AlertCircle className="h-3.5 w-3.5" />
              Projetos em risco
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">{projetosEmRisco}</div>
            <p className="text-xs text-muted-foreground mt-1">Prazo próximo/vencido</p>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Distribuição por técnico */}
        <Card>
          <CardHeader>
            <CardTitle>Distribuição por Técnico</CardTitle>
            <CardDescription>Chamados ativos por responsável</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={dadosPorTecnico}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="nome" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="chamados" fill="#1e3a8a" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Distribuição por tipo */}
        <Card>
          <CardHeader>
            <CardTitle>Distribuição por Tipo</CardTitle>
            <CardDescription>Categorias de chamados no backlog</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie
                  data={dadosPorTipo}
                  dataKey="valor"
                  nameKey="tipo"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={(entry) => entry.tipo}
                >
                  {dadosPorTipo.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CORES[index % CORES.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Aging por faixas */}
        <Card>
          <CardHeader>
            <CardTitle>Aging do Backlog</CardTitle>
            <CardDescription>Distribuição por tempo de abertura</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={dadosAgingFaixas} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis type="number" tick={{ fontSize: 12 }} />
                <YAxis dataKey="faixa" type="category" tick={{ fontSize: 12 }} width={60} />
                <Tooltip />
                <Bar dataKey="chamados" fill="#06b6d4" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top 5 clientes */}
        <Card>
          <CardHeader>
            <CardTitle>Top 5 Clientes</CardTitle>
            <CardDescription>Maior volume de chamados ativos</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={top5Clientes} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis type="number" tick={{ fontSize: 12 }} />
                <YAxis
                  dataKey="nome"
                  type="category"
                  tick={{ fontSize: 11 }}
                  width={100}
                />
                <Tooltip />
                <Bar dataKey="chamados" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
