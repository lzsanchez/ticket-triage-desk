import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { useAuth } from "@/lib/auth";
import { mockUsuarios } from "@/data/mockUsuarios";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Settings, Users, FileType, Link2 } from "lucide-react";

export const Route = createFileRoute("/configuracoes")({
  component: ConfiguracoesPage,
});

function ConfiguracoesPage() {
  return (
    <AppShell>
      <Configuracoes />
    </AppShell>
  );
}

function Configuracoes() {
  const { user } = useAuth();

  if (!user) return null;
  if (user.role !== "gestor") return <Navigate to="/" />;

  return (
    <div>
      {/* Header */}
      <div className="flex items-end justify-between gap-4 pb-6">
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Sistema</p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight text-foreground">
            Configurações
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Gerenciar usuários, tipos de chamado e integração com GLPI.
          </p>
        </div>
      </div>

      <Tabs defaultValue="usuarios" className="space-y-6">
        <TabsList>
          <TabsTrigger value="usuarios">
            <Users className="h-4 w-4 mr-1.5" />
            Usuários
          </TabsTrigger>
          <TabsTrigger value="tipos">
            <FileType className="h-4 w-4 mr-1.5" />
            Tipos de Chamado
          </TabsTrigger>
          <TabsTrigger value="glpi">
            <Link2 className="h-4 w-4 mr-1.5" />
            Integração GLPI
          </TabsTrigger>
        </TabsList>

        <TabsContent value="usuarios">
          <UsuariosTab />
        </TabsContent>

        <TabsContent value="tipos">
          <TiposChamadoTab />
        </TabsContent>

        <TabsContent value="glpi">
          <IntegracaoGLPITab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function UsuariosTab() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Usuários do Sistema</CardTitle>
        <CardDescription>
          Atualmente são 3 usuários fixos. Gerenciamento completo será implementado em breve.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {mockUsuarios.map((usuario) => (
            <div
              key={usuario.id}
              className="flex items-center justify-between p-3 rounded-md border border-border bg-card"
            >
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-sm font-semibold text-primary">
                    {usuario.nome.split(" ").map((n) => n[0]).join("")}
                  </span>
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">{usuario.nome}</p>
                  <p className="text-xs text-muted-foreground">{usuario.email}</p>
                </div>
              </div>
              <Badge variant={usuario.perfil === "gestor" ? "default" : "secondary"}>
                {usuario.perfil === "gestor" ? "Gestor" : "Analista"}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function TiposChamadoTab() {
  const tipos = [
    "Instalação",
    "Consulta de Multa e Cancelamento",
    "Dúvida",
    "Upgrade Links Mobit",
    "Estudo de Renovação",
    "Remanejamento de Link",
    "Reparo Técnico",
    "Atualização de Inventário",
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Tipos de Chamado</CardTitle>
        <CardDescription>
          Categorias reconhecidas automaticamente ao importar do GLPI.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {tipos.map((tipo) => (
            <Badge key={tipo} variant="outline" className="text-sm px-3 py-1">
              {tipo}
            </Badge>
          ))}
        </div>
        <p className="mt-4 text-xs text-muted-foreground">
          Novos tipos são detectados automaticamente durante a importação de chamados.
        </p>
      </CardContent>
    </Card>
  );
}

function IntegracaoGLPITab() {
  const [url, setUrl] = useState("https://glpi.exemplo.com.br");
  const [userToken, setUserToken] = useState("");
  const [appToken, setAppToken] = useState("");
  const [frequencia, setFrequencia] = useState("10");

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Conexão com GLPI</CardTitle>
          <CardDescription>
            Configure as credenciais de acesso à API REST do GLPI para sincronização automática.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="glpi-url">URL do GLPI</Label>
            <Input
              id="glpi-url"
              placeholder="https://glpi.exemplo.com.br"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="user-token">User Token</Label>
            <Input
              id="user-token"
              type="password"
              placeholder="Token do usuário GLPI"
              value={userToken}
              onChange={(e) => setUserToken(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="app-token">App Token</Label>
            <Input
              id="app-token"
              type="password"
              placeholder="Token da aplicação"
              value={appToken}
              onChange={(e) => setAppToken(e.target.value)}
            />
          </div>

          <Separator />

          <div className="space-y-2">
            <Label htmlFor="frequencia">Frequência de sincronização (minutos)</Label>
            <Input
              id="frequencia"
              type="number"
              min="5"
              max="60"
              value={frequencia}
              onChange={(e) => setFrequencia(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              A plataforma consultará a API do GLPI a cada {frequencia} minutos.
            </p>
          </div>

          <div className="flex gap-2 pt-2">
            <Button>Testar Conexão</Button>
            <Button variant="outline">Salvar Configurações</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Status da Integração</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-amber-500" />
            <span className="text-sm text-muted-foreground">
              Integração não configurada. Configure as credenciais acima para ativar.
            </span>
          </div>
          <p className="mt-4 text-xs text-muted-foreground">
            Quando ativa, a plataforma sincronizará automaticamente: ID do chamado, título,
            entidade (cliente), técnico atribuído, última atualização e data de abertura.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
